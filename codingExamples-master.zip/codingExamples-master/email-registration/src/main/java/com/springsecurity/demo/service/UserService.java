package com.springsecurity.demo.service;

public interface UserService {

}
