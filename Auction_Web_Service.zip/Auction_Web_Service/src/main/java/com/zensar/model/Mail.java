package com.zensar.model;

public class Mail {

	private String senderEmailAddress;
	private String recipientEmailAddress;
	private String subject;
	private String message;
}
