# spring-email-verification
An application to verify new user account via email confirmation.

Implements user login and registration using Spring MVC and Spring Security. 
