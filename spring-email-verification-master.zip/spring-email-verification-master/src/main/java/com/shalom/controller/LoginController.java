package com.shalom.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

	

	// add request mapping for access denied

	
}